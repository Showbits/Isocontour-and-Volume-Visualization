Assignment zip file contains:
1) Data
2) Part1.py
3) Part2.py
4) README.txt

Part1 is the code for the first Question of Assignment which takes isovalue as an input
parameter and output the extracted contour as a *.vtp (VTKPolyData) file.

To run the script using the following command in command prompt :
python Part1.py 

After giving enter, it will ask "Enter Iso Value:" so you have to write for which Iso value 
you want to extract contour. After entering the Iso value , output.vtp file will be created.
The output file can be read in ParaView.

Part2 is the code for the second Question of Assignment which takes if user wants to use phong
shading or not.

To run the script using the following command in command prompt :
python Part2.py 

After giving enter, it will ask "Enter y or n :" so you have to enter y if you want phong
shading else you have to enter n.
The output of this script will be rendered the image.

